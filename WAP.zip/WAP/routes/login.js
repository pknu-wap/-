var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('login.html', {
        title: 'login'
    });
});

router.post('/', function (req, res, next) {
    var paramId = req.body.loginId || req.query.loginId;
    
    console.log('paramId : ' + paramId);
    
    // user 세션 저장.
    req.session.user = {
        id: paramId,
        authorized: true
    }
    
    console.log('세션이 생성되었습니다. 세션 id = ' + req.session.user.id);
    
    res.render('login_process.html');
});

module.exports = router;
