var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/canvas/:roomName', function(req, res, next) {
    var room = req.param.roomName;
    res.render('canvas.html', { room: room });
});

module.exports = router;