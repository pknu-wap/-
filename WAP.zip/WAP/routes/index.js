var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
    // 이미 세션이 있음.
    if (req.session.user) {
        console.log('해당 세션이 이미 존재함.');
        
        res.render('process_login.html', {
           title: 'Mapia' 
        });
    } else {
        console.log('세션이 없습니다.');
        res.render('login.html', { title: 'login' });
    }
});

module.exports = router;
