// 기본 모듈 추출
var http = require('http');
var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var expressSession = require('express-session');
var ejs = require('ejs');

// 라우터 모듈 추출.
var indexRouter = require('./routes/index');
var loginRouter = require('./routes/login');
var mainRouter = require('./routes/main');
var makeRoomRouter = require('./routes/makeRoom');
var canvasRouter = require('./routes/canvas');

// 소켓 모듈 추출
var socketio = require('socket.io');

// 파일 업로드용 모듈.
var multer = require('multer');
var fs = require('fs');

// cors 사용 - 클라이언트에서 ajax로 요청하면 CORS 지원
var cors = require('cors');

// room 배열 선언.
var roomArray = [];

// 서버 생성.
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

/* middleware setup */
// URL 요청 시 대소문자 구분.
app.set('case sensitive routes', true);

// cors를 미들웨어로 사용하도록 등록
app.use(cors());
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({
    extended: false
}));
app.use(cookieParser());
app.use(expressSession({
    secret: 'my key',
    resave: true,
    saveUninitialized: true
}));
app.use(express.static(path.join(__dirname, 'public')));

// 업로드 폴더 오픈.
app.use('upload', express.static(path.join(__dirname, 'upload')));

app.use('/', indexRouter);
app.use('/login', loginRouter);
app.use('/main', mainRouter);
app.use('/makeRoom', makeRoomRouter);
app.use('/canvas', canvasRouter);


app.get('/canvas/:room', function (request, response) {
    fs.readFile('canvas.html', 'utf8', function (error, data) {
        response.send(ejs.render(data, {
            room: request.params.room
        }));
    });
});

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});

var port = '3000';

var server = http.createServer(app).listen(port, function () {
    console.log('서버가 시작되었습니다. 포트: ' + port);
});

var io = socketio.listen(server);
console.log('소켓을 사용할 준비가 되었습니다.');

// 로그인 아이디 매핑
var login_ids = {};

// 소켓 연결.
io.sockets.on('connection', function (socket) {
    // 로그인
    socket.on('login', function (login) {
        console.log('login 이벤트를 받음.');
        console.dir(login);

        console.log('접속한 소켓의 ID: ' + socket.id);
        console.log('접속한 ID: ' + login.id);
        login_ids[login.id] = socket.id;
        socket.login_id = login.id;

        console.log('접속한 클라이언트 ID 개수 %d', Object.keys(login_ids).length);

        socket.emit('response', '로그인 성공!');
    });
    
    // 방에 대한 소켓.
    socket.on('room', function (room) {
        console.log('room 이벤트 받음.');
        console.dir(room);

        if (room.command == 'create') {
            if (io.sockets.adapter.rooms[room.roomName]) {
                console.log('이미 방이 만들어져 있습니다.');
            } else {
                console.log('방을 새로 만듭니다.');

                socket.join(room.roomName);

                var curRoom = io.sockets.adapter.rooms[room.roomName];
                curRoom.name = room.roomName;
                
                socket.emit('response', '방 만들기 성공!');
            }
        }
        
        var roomList = getRoomList();

        var output = {
            command: 'list',
            rooms: roomList
        };
        console.log('클라이언트로 보낼 데이터: ' + JSON.stringify(output));

        io.sockets.emit('room', output);
        
        function getRoomList() {
            console.dir(io.sockets.adapter.rooms);
            
            var roomList = [];
            
            Object.keys(io.sockets.adapter.rooms).forEach(function(roomName) {
                console.log('current room name: ' + roomName);
                
                var outRoom = io.sockets.adapter.rooms[roomName];
                
                var fountDefault = false;
                var index = 0;
                Object.keys(outRoom.sockets).forEach(function(key) {
                    console.log('#' + index + ': ' + key + ', ' + outRoom.sockets[key]);
                
                    if (roomName == key) {
                        fountDefault = true;
                        console.log('this is default room');
                    }
                    index++;
                });
                
                if (!fountDefault) {
                    roomList.push(outRoom);
                }
            });
            
            console.log('[ROOM LIST]');
            console.dir(roomList);
            
            return roomList;
        }
    });
});
module.exports = app;
